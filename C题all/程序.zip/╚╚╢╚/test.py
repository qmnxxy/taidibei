# from triple_extraction import *
# extractor = TripleExtractor()
import pandas as pd

# 处理原始数据进行正则替换
# def process_txt(data):
#     pattern = re.compile("[^\u4e00-\u9fa5]")
#     # 设置正则匹配的表达式，只保留中英文，数字和符号，去除掉其他东西
#     line = re.sub(pattern, '', data)
#     # 把文本中匹配到的字符替换成空字符
#     new_sentence = ''.join(line.split())
    # 去除空白
    # return new_sentence
# svos = extractor.triples_main(content)
# print('svos', svos)
from baidu_svo_extract import *
import time
data = pd.read_excel("E:/DESK/EventTriplesExtraction/code/code_test/data/2020-2021茂名（含自媒体）.xlsx",header=0, sheet_name="餐饮评论")
# 加载数据
data_min = []
# data['main'] = data['餐饮名称']+" "+data['评论内容']
datai= data.drop_duplicates(["评论内容"], inplace=False).reset_index(drop=True)
datai=datai.dropna()

data_c_f = datai[datai["评论内容"].apply(len) > 3]

extractor = SVOParser()
# data_c_f['main'] = data_c_f['餐饮名称']+" "+data_c_f['评论内容']
data_c_f['result']=data_c_f['main'].apply(lambda x:extractor.triples_main(
    x
))
# dt=[]
# # time.sleep(2)
# for i in data_c_f["main"][0:5]:
#
#     extractor = SVOParser()
#
#     svos = extractor.triples_main(i)
#     print(svos)
    # dt.append(svos)
# dat_s=pd.DataFrame(dt)
# dat_s.to_csv("2020餐饮评论.csv",encoding="utf-8")
    # from pattern_event_triples import *
# import handler
# content = '李克强总理今天来我家了,我感到非常荣幸'
# extractor = ExtractEvent()
# events, spos = handler.phrase_ip(content)
# spos = [i for i in spos if i[0] and i[2]]
# print('svos', spos)