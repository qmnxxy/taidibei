import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
ltqb=pd.read_excel("旅游产品提取表.xlsx",engine="openpyxl",header=0)
ltqb["计数项"]=ltqb["计数项"].apply(lambda x:int(x))
yjgl=pd.read_excel("2018-2019茂名（含自媒体）.xlsx",engine="openpyxl",header=0,sheet_name="景区评论")
# yjgl=pd.read_excel("2020-2021茂名（含自媒体）.xlsx",engine="openpyxl",header=0,sheet_name="景区评论")
# for i in yjgl["酒店名称"]:
#     print(i)
y_g=yjgl.groupby(["景区名称","label"])
#评论日期转为时间型
yjgl["评论日期"]=yjgl["评论日期"].apply(lambda x:datetime.strptime(x,'%Y-%m-%d'))
# y_g=yjgl.groupby(["餐饮名称","label"])
# labelm =yjgl.groupby(["餐饮名称","label"])["餐饮名称"].transform()
# max_eachgroup =yjgl.groupby(["餐饮名称","label"])["评论日期"].transform('max') # 获取每个分组的最小值并增量转换为和原来维度相同
# min_eachgroup =yjgl.groupby(["餐饮名称","label"])["评论日期"].transform('min')
# dual=max_eachgroup-min_eachgroup
# df['no'] = df['no'] - min_eachgroup # 每一组的值都减去该组的最小值，即每条迹第2--last个活动到第1个活动的跨度
# print(y_g.get_group("城市便捷酒店(茂名学府店)"))
ss=yjgl.groupby(["景区名称"]).agg(['min','max'])
# # print(ss.columns)
# ss[(  '评论日期', 'max')]=ss[(  '评论日期', 'max')].apply(lambda x:datetime.strptime(x,'%Y-%m-%d'))
# ss[(  '评论日期', 'min')]=ss[(  '评论日期', 'min')].apply(lambda x:datetime.strptime(x,'%Y-%m-%d'))
# y = pd.to_numeric((ss[(  '评论日期', 'max')]-ss[(  '评论日期', 'min')]).days, downcast='integer')
tt=ss[(  '评论日期', 'max')]-ss[(  '评论日期', 'min')]
tt.to_csv("2018景区间隔日期n.csv")
# tt.to_csv("2018酒店间隔日期n.csv")
# ss["日期"]=ss
# jd=[]
# dual_1=[]
# df={}
# for i in y_g:
#     print(i[1]["评论日期"])
#     a=i[1]["评论日期"].max()
#     b=i[1]["评论日期"].min()
#     y = pd.to_numeric((a-b).days, downcast='integer')
#     jd.append(i[0][0])
#     dual_1.append(y)
# df={'餐饮名称':jd,'天数':dual_1}
# sh=pd.DataFrame(df,columns=["餐饮名称","天数"])
# def fun(x):
#     if x==0:
#         x=1
#     return x
# sh["天数"]=sh["天数"].apply(lambda x:fun(x))
# sh.to_csv("2018餐饮评论日期.csv",index=None)
'''jdmz=[]
senti=[]
kk=[]
kj=[] # ID
main=[] # neirong
for i in y_g:
    print(i)
    k=i[1]["label"].count()
    for j in i[1][0]:
        print(j[0])
    kj.append(i[1].iloc(0))
    jdmz.append(i[0][0])
    senti.append(i[0][1])
    main.append(i[1].iloc(3))
    kk.append(k)
df={'ID':kj,'景区名称':jdmz,"内容":main,'label':senti,'count':kk}
s=pd.DataFrame(df,columns=["ID","景区名称","内容","label","count"])
s_kk=s.groupby(["景区名称"])
s_k=s.groupby(["景区名称"])[['count']].sum()
# s_l=pd.concat([s_kk,s_k])
ss=s.groupby(["景区名称"]).apply(lambda x:x)

s_k_dict=s_k.to_dict()
t=s_k_dict.values()
for i in t:
    k_k=i
# for i in k_k.get:
#     print(i)
def matcher(k):
    x = (i for i in k_k  if i in k)
    return map(k_k.get, x)
ss['values'] = ss['景区名称'].apply(lambda x:list(matcher(x)))
ss['values']=ss['values'].apply(lambda x:x[0])
ss['比率']=ss["count"]/ss["values"]
yy_g=ss.groupby(["label"]).apply(lambda x:x)
yy_g.to_csv("2018景区情感统计表_1.csv",index=None)
# s_k.to_csv("2018酒店评论次数统计表.csv",index=None)
# ss['values']=ss['values'].str.extract(r'(\d)',expand=False)
# for i in s_k_dict.values():
#     for k ,j in i.items():
#         for z in ss["酒店"]:
#         # print(ss["酒店"].loc(k))
#             if z==j:

        # ss["count_c"]=ss["酒店"].apply(lambda x:x=loc)
plt.hist(s["count"])
plt.show()
# print    kk=len(i[0][1])
#     print(kk)
#     jdmz.append(i[0][0])
#     senti.append(i[0][1])

# s_gr=s.groupby("酒店")
# for i in s_gr:
#     c=(i[1][2]=1).sum()
# print(y)

'''