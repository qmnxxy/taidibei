import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
ltqb=pd.read_excel("旅游产品提取表.xlsx",engine="openpyxl",header=0)
ltqb["计数项"]=ltqb["计数项"].apply(lambda x:int(x))
yjgl=pd.read_excel("2018-2019茂名（含自媒体）.xlsx",engine="openpyxl",header=0,sheet_name="酒店评论")
# yjgl=pd.read_excel("2020-2021茂名（含自媒体）.xlsx",engine="openpyxl",header=0,sheet_name="景区评论")
cc=yjgl.sort_values(by=['酒店名称','label'])
cc.to_csv("2018酒店评论.csv")
# cc.to_csv("2020景区评论.csv")