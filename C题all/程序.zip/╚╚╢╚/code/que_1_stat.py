import codecs
import numpy as np
import pandas as pd
import jieba
import re
import tqdm
import os
from gensim import corpora, models, similarities
import jieba.analyse
import csv
import matplotlib.pyplot as plt
import gensim
from sklearn.feature_extraction.text import CountVectorizer
from transformers import BertTokenizer
from gensim.models.doc2vec import Doc2Vec
import pickle
import io
import os
import re
import nltk
import jieba.posseg as pseg
import jieba
# from pyltp import SentenceSplitter
from nltk.tokenize import WordPunctTokenizer
from snownlp import SnowNLP
from sklearn.feature_extraction.text import CountVectorizer
import numpy as np
from sklearn.utils import shuffle
from tqdm import tqdm_notebook
from nltk.corpus import stopwords
from top2vec import Top2Vec
from tqdm import tqdm
import pandas as pd
from sentence_transformers import SentenceTransformer
tqdm.pandas(desc='pandas bar')

def condense(st):
    for i in range(1, int(len(st) / 2) + 1):
        for j in range(len(st)):
            if st[j:j + i] == st[j + i:j + 2 * i]:
                k = j + i
                while st[k:k + i] == st[k + i:k + 2 * i] and k < len(st):
                    k = k + i
                st = st[:j] + st[k:]
    return st


# 读取文本文件
def read_txt(path):
    with open(path, encoding='utf-8') as txt:
        temp = txt.read()
        stop_words = temp.splitlines()
    return stop_words





def process_pair():
    f = codecs.open("../code_test/data/pair_sort_[0,1]", mode='r', encoding='utf-8')
    line = f.readline()
    list1 = []
    while line:
        a = line.split()
        b = a[0:1]
        list1.append(b)
        line = f.readline()
    f.close()
    trans_list = []
    for i in range(len(list1)):
        temp = ''.join(list1[i])
        trans_list.append(temp)
    return trans_list
def process_txt(data):
    data=str(data)
    pattern = re.compile("[^\u4e00-\u9fa5^,^.^!^0-9]")
    # 设置正则匹配的表达式，只保留中英文，数字和符号，去除掉其他东西
    line = re.sub(pattern, '', data)
    # 把文本中匹配到的字符替换成空字符
    new_sentence=''.join(line.split())
    # 去除空白
    return new_sentence



data = pd.read_excel("../code_test/data/2018-2019茂名（含自媒体）.xlsx",engine="openpyxl", sheet_name="微信公众号新闻")
# 加载数据
data_min = []
for sentence in data["正文"]:
    data_mine = process_txt(sentence)
    data_min.append(data_mine)
data_mi = {"公众号文章内容_0": data_min}
data_min = pd.DataFrame(data_mi)
# 查看评论长度分布情况

# data_min=data_min.apply(len(data_min))
# 经过处理之后的公众号文章内容
stop_wd = read_txt("../code_test/data/cn_stopwords.txt")
stp = ['陈小姐', '林小姐', '茂名市', '茂名', '小姐', '吴小姐', '林小姐', '谢小姐','中','月','说','站','时','日','点击','里']
for i in stp:
    stop_wd.append(i)
# print(stop_wd)
# 加载停用词
# 分词并过滤停用词
comments_segs = []
# 用来存放所有的文章处理之后的结果
for sentence in data_min["公众号文章内容_0"]:
    comments_seg = []
    # 用来存放每一条文章处理之后的结果
    segs = jieba.cut(sentence, cut_all=False)
    # 进行分词
    for seg in segs:
        # 判断是否属于停用词
        if seg not in stop_wd:
            comments_seg.append(seg)

    comments_segs.append(comments_seg)
    comments_segs_mi = {"分词后结果": comments_segs}
    comments_segs_min = pd.DataFrame(comments_segs_mi)
    # comments_segs_min为当前分词后的结果
data_c = pd.concat([data, comments_segs_min], axis=1)
# data_c 为 标题，发布时间，正文，分词后结果
# 查看文章长度分布情况
num = data_c["分词后结果"].apply(len)
plt.hist(num, 50)
plt.show()
# 选取分词后结果长度大于10的结果
data_c_f = data_c[data_c["分词后结果"].apply(len) > 140]
# 对标题进行去重
dataf = data_c_f.drop_duplicates(["公众号标题"], inplace=False).reset_index(drop=True)
# ind = data_after.apply(len)>5
# 先构造词典(所有分词结果做去重)
'''
for i in data_c['分词后结果']:
    # print(type(i))
    result=set(i)
    print(result)
'''

deg = []
# 空列表添加主题词 top
top=[]
# 分别添加
main_1=[]
main_2=[]
main_3=[]
main_4=[]
main_5=[]
for cc in dataf["分词后结果"]:
    ccc = [d.split() for d in cc]
    dictionary = corpora.Dictionary(ccc)
    dictionary.filter_extremes(no_below=2, no_above=0.6)
    # 词袋模型
    corpus = [dictionary.doc2bow(text) for text in ccc]
    #建立lsi模型
    lsi_bow=models.LsiModel(
        corpus,id2word=dictionary,num_topics=1,onepass=True,chunksize=1740,power_iters=1000
    )
    # 主题获取
    topics=[[
    (term,round(wt,1))
        for term,wt in lsi_bow.show_topic(n,topn=5)] for n in range(0,3)]
    #打印主题
    for idx,topic in enumerate(topics):
        top.append(topic)
        # print(sss)
        top_mi = {"topic_m": top}
        top_main = pd.DataFrame(top_mi)

        top_main=top_main[~(top_main['topic_m'].str.len() <3)].reset_index(drop=True)
print(top_main)
for j in top_main['topic_m']:
        # print(j)
    main_1.append(j[0][0])
    main_2.append(j[1][0])
    main_3.append(j[2][0])
    main_4.append(j[3][0])
    main_5.append(j[4][0])
deg_frame=pd.DataFrame([main_1,main_2,main_3,main_4,main_5]).T
deg_frame.columns=['主题词1','主题词 2','主题词 3','主题词 4','主题词 5']
dtac=pd.concat([dataf,deg_frame],axis=1,ignore_index=True)
# datac = pd.concat([data_c,deg_frame, pd.DataFrame(columns=['degg'])], sort=False)
dtac_c=pd.concat([dtac,pd.DataFrame(columns=["是否相关"])],sort=False)
columns=['文章ID','公众号标题','发布时间','正文','分词结果','主题词1','主题词 2','主题词 3','主题词 4','主题词 5','是否相关']
dtac_c.columns=columns
# def get_pg_type(x):
#     for i in x:
#         if x[i] in trans_list:
#             return "1"
#         else:
#             return "-1"
dtac_c['文章ID']=dataf['文章ID']
def topic_correlation(x,y,z,k,l):
    if x in trans_list or y in trans_list and z in trans_list and k in trans_list or l in trans_list:
        return "相关"
    else:
        return "不相关"
dtac_c["是否相关"] =dtac_c.apply(lambda x: topic_correlation(x['主题词1'],x['主题词 2'],x['主题词 3'],x['主题词 4'],x['主题词 5']), axis = 1)
dtac_c_result=pd.DataFrame([dtac_c["文章ID"],dtac_c["是否相关"]]).T

dtac_c_result.to_csv("../code_test/data/result1_1.csv")
dtac_c.to_csv("../code_test/data/2018.csv")
# for i in dtac_c["是否相关(相关为1)"]:
#     if dtac_c['主题词2'].all() in trans_list:
#         dtac_c.loc[i, "是否相关(相关为1)"] = 1
#     else:
#         dtac_c.loc[i, "是否相关(相关为1)"] = 0
# # Average topic coherence is the sum of topic coherences of all topics, divided by the number of topics.
# avg_topic_coherence = sum([t[1] for t in top_topics]) / 3
# print('Average topic coherence: %.4f.' % avg_topic_coherence)


# term,wt =lda.show_topic(3,topn=20)
# print(term,wt)
# print(lda.print_topics(num_topics=5))

# print(lda.print_topics(num_topics=3))

# for se in data_c["分词后结果"]:
#     se =str(se)
#     c= jieba.analyse.extract_tags(se,topK=5,withWeight=True,allowPOS=())
#     # 抽取主题
#     deg.append(c)
# print(deg[0])

# datac = pd.concat([data_c,deg_frame, pd.DataFrame(columns=['degg'])], sort=False)
# def get_pg_type(x):
#     for i in x:
#         if x[i] in trans_list:
#             return "1"
#         else:
#             return "-1"
# datac.loc[:,"degg"] = datac.apply(get_pg_type,axis=1)
# print(datac)


# if __name__ == "__main__":
# print(datac)x
#
#
#     with open('result.csv', 'a', encoding='utf-8', newline='') as f_csv:
#         csv_writer = csv.writer(f_csv)
#         # 3. 构建列表头
#         csv_writer.writerow(["文章ID", "内容","词1", "词2", "词3", "词4", "词5",  "相关性"])
#         # 4. 写入csv文件内容
#         for i in range(len(deg)):
#             name = []
#             flag = 0
#             for j in range(len(deg[i])):
#                 name.append(deg[i][j][0])
#                 if(deg[i][j][0] in trans_list):flag = 1
#             name.append(data_c["文章ID"][i])
#             name.append(data_c["公众号标题"][i])
#             name.append(data_c["发布时间"][i])
#             # print(name[6])
#
#             if(flag == 1):
#                 name.append("1")
#             else:
#                 name.append("-1")
#             print(name)
# csv_writer.writerow([name[5], name[6],name[0], name[1], name[2], name[3], name[4]])
# print(name)
    # mallet_lda_model = gensim.models.wrappers.LdaMallet(
    #     mallet_path=MALLET_PATH,
    #     corpus=corpus,
    #     num_topics=1,
    #     id2word=dictionary,
    #     iterations=10,
    #     workers=16
    # )
    # mallet_lda_model.show_topics(num_topics=1,num_words=5,formatted=False)

    # def print_top_words(model, feature_names, n_top_words):
    #     for topic_idx, topic in enumerate(model.components_):
    #         print('\nTopic Nr.%d:' % int(topic_idx + 1))
    #     print(''.join(
    #         [feature_names[i] + ' ' + str(round(topic[i], 2)) + ' | ' for i in topic.argsort()[:-n_top_words - 1:-1]]))


    # n_top_words = 20  # 主题输出前20个关键词
    # tf_feature_names = tf_vectorizer.get_feature_names()
    # mallet_lda_model.show_topic(num_words=5,topicid=1)
    # mallet_lda_model.
    #
    # for topic in mallet_lda_model.print_topics(num_words=5,f):
    #     m_v.append(topic)
    #     for i in m_v:
    #         print(i)
    # s_s=re.sub("[^\u4e00-\u9fa5]"," ",models[0][1])
    # topic=lsi_bow.print_topics(num_topics=1,num_words=5)
    # lda = models.LdaModel(corpus=corpus, id2word=dictionary, num_topics=3)
    # top_topics = lda.top_topics(corpus)  # , num_words=20)
    # 打印出主题
    # for topic in lsi_bow.print_topics(num_words=5):
    #     print(topic)