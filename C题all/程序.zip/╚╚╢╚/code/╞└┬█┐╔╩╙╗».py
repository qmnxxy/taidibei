import seaborn as sns
import matplotlib.pyplot as  plt
import pandas as pd
import numpy as np
jd=pd.read_excel("C:/Users/Administrator/Documents/WXWork/1688850063228278/Cache/File/2022-04/旅游产品提取表.xlsx",header=0,engine="openpyxl",sheet_name="cc")
jd_g=jd.sort_values(by=["count"]).reset_index(drop=True)
jd_g=jd_g.sort_values(by="count",ascending=False)
# sns.set(style='ticks',context='notebook')
fig = plt.figure(figsize=(50,20))
sns.set_style("darkgrid")
font1 = {'family': 'SimHei',
         'weight': 'bold',
		 'style':'normal',
         'size': 80,
         }
plt.rcParams['font.sans-serif'] = ['SimHei']
sns.barplot(x ="name", y = "count", data = jd_g)
# plt.xlim("")
plt.title("2018年景区评论总数",font1)
plt.xlabel("景区名称",font1)
plt.ylabel("评论总数",font1)
# plt.tick_params(axis='x', labelsize=10)
plt.xticks(rotation=-18)
plt.show()
